# Rationalizer — Methodology & Rules Philosophy

## Purpose
This document captures the full methodology for how the Rationalizer's rules were derived and the conservative logic behind them. It is intended to allow a new Claude instance (on any computer) to reproduce, update, or extend the rules faithfully.

---

## Core Philosophy: Underflag, Don't Overflag

**The single most important principle:** It is better to MISS a disclosure placement than to recommend one incorrectly.

Why: If the tool overflag (recommends disclosures where they aren't needed), users stop trusting it. A false positive erodes confidence faster than a false negative. The rules must be conservative — they should only fire when the evidence is unambiguous and specific.

**When writing or updating rules, always ask:**
- "Could this trigger fire on a slide where the disclosure is NOT actually needed?" If yes, tighten it.
- "Am I triggering on a topic/theme, or on specific concrete evidence?" Only trigger on concrete evidence.
- "Does this rule have guardrails?" Every rule should say what it does NOT trigger on.

---

## Rule Structure

Every rule in `uploads/rules.json` has three fields:

```json
{
  "disclosure_name": {
    "placement": "footnote" or "back",
    "rule": "Plain English description of when to trigger. Must include 'Do NOT trigger on...' guardrails.",
    "triggers": ["specific phrase 1", "specific phrase 2"]
  }
}
```

**Placement definitions:**
- `footnote` — disclosure appears on the same page as the trigger (page footnote)
- `back` — disclosure appears in the back/endnotes/appendix of the document

---

## How the Rules Were Originally Derived

### Step 1: Extract PDF text
Using Docling (`pip3 install docling`), extract full text from all "gold star" finished documents:

```python
from docling.document_converter import DocumentConverter
converter = DocumentConverter()
result = converter.convert("path/to/document.pdf")
markdown_text = result.document.export_to_markdown()
```

### Step 2: Find where each disclosure appears
For each of the 18 disclosures, search the extracted text for key phrases from the disclosure language. Note:
- Which document it appeared in
- What content surrounded it (what was on the same page/slide)
- Whether it appeared as a page footnote or in a back-of-document section

### Step 3: Identify the trigger pattern
Look at the content that preceded or surrounded each disclosure appearance. Ask:
- Is there a specific word or phrase that always appears when this disclosure is needed?
- Is this a specific slide type (e.g., fund performance table, case study)?
- Is there a pattern across multiple documents?

### Step 4: Write conservative rules
Write the rule with:
1. A specific, concrete trigger condition (not a broad topic)
2. Explicit "Do NOT trigger on..." exclusions
3. A short list of exact trigger phrases or slide types

---

## The 18 Disclosures and Their Conservative Rules

### 1. illustrative_purposes_only
- **Placement:** footnote
- **Trigger:** ONLY on single-company case study/spotlight slides explicitly labeled "Case Study", "Company Spotlight", or "Featured Investment"
- **Do NOT trigger on:** general portfolio tables, passing mentions of a company

### 2. gross_returns
- **Placement:** footnote
- **Trigger:** ONLY when a slide shows an explicit column/row labeled "Gross IRR", "Gross MOIC", "Gross Realized MOIC", "Gross Unrealized MOIC", or "Gross Total MOIC" with numeric values
- **Do NOT trigger on:** prose discussion of returns, non-performance use of "gross"

### 3. gross_gains_losses
- **Placement:** footnote
- **Trigger:** ONLY on the specific "Performance by Fund" table showing "Q[N] Gross Gain/(Loss)$" and "Q[N] Net Gain/(Loss)$" side by side across multiple funds
- **Do NOT trigger on:** general performance tables, fund snapshots, mentions of gains/losses

### 4. indices_and_benchmarks
- **Placement:** footnote
- **Trigger:** ONLY when a slide shows explicit side-by-side comparison of TCV returns vs. a named index (Russell 2000, S&P 500, Nasdaq, PME) with actual numeric figures for both
- **Do NOT trigger on:** passing mentions of an index, references without numerical comparison

### 5. timeline_guarantee
- **Placement:** footnote
- **Trigger:** ONLY on single-company case study slides with an explicit "Value Creation Plan" or "Value Creation Initiatives" section listing specific milestones or timelines
- **Do NOT trigger on:** general portfolio tables, passing mentions of value creation, fund strategy slides

### 6. rounding
- **Placement:** footnote
- **Trigger:** ONLY on financial tables with a visible Total row/column where individual line items are summed, at a precision level where rounding discrepancies would be noticeable
- **Do NOT trigger on:** charts, prose, tables without explicit sum totals

### 7. partners_and_advisors
- **Placement:** back
- **Trigger:** ONLY on slides explicitly dedicated to listing Operating Partners, Senior Advisors, or Executive Advisors as a named roster or directory
- **Do NOT trigger on:** brief mentions of an advisor by name, passing advisory references

### 8. funnels_pipelines
- **Placement:** footnote
- **Trigger:** ONLY on slides showing an explicit funnel/pipeline diagram with labeled stages and numeric company counts at each stage
- **Do NOT trigger on:** prose descriptions of sourcing process, general strategy slides

### 9. summary_ddq
- **Placement:** back
- **Trigger:** ONLY on slides explicitly labeled as a DDQ summary, investment process overview, or decision-making process — typically in a due diligence questionnaire context
- **Do NOT trigger on:** general strategy slides, passing mentions of process

### 10. liquidity
- **Placement:** footnote
- **Trigger:** ONLY on slides showing a table of liquidity events explicitly filtered to a subset (e.g., "Select Liquidity", "Total Liquidity >$25M"), where the heading makes clear it is not a complete list
- **Do NOT trigger on:** general mentions of liquidity, fund-level DPI figures

### 11. advisor_network
- **Placement:** footnote
- **Trigger:** ONLY on slides displaying a curated named roster of Advisor Network members with names and titles, where the slide explicitly references "Advisor Network"
- **Do NOT trigger on:** passing mentions of advisors, single advisor named in context

### 12. gross_net_fund_metrics
- **Placement:** footnote
- **Trigger:** ONLY on fund snapshot/track record slides showing BOTH fund size AND net performance metrics (Net IRR, Net MOIC, Net DPI) in the same table, where fund size covers all parallel entities but performance reflects only fee-paying LP cash flows
- **Do NOT trigger on:** gross-only slides, net-only slides, fund size without performance

### 13. company_logos
- **Placement:** back
- **Trigger:** ONLY on slides displaying a grid or collection of multiple company logos as the primary visual content (portfolio overview, logo grid, fund summary with logos)
- **Do NOT trigger on:** single company logo appearing incidentally in a case study header or cover

### 14. ai_technology_assurances
- **Placement:** back
- **Trigger:** ONLY when a slide explicitly describes AI or ML as a component of TCV's investment sourcing, screening, or monitoring process with specific claims about what the technology does
- **Do NOT trigger on:** AI as a portfolio theme, AI as a market trend, AI as a characteristic of a portfolio company

### 15. not_representative_of_all_investments
- **Placement:** footnote
- **Trigger:** ONLY on slides showing a filtered subset of portfolio companies where the filter criteria are explicitly stated (e.g., "Active investments with FMV > $50M", "Investments made after 2020")
- **Do NOT trigger on:** slides showing all investments in a fund, case study slides (covered by illustrative_purposes_only), slides with no explicit filter stated

### 16. past_performance
- **Placement:** footnote
- **Trigger:** ONLY on the primary multi-fund track record table showing historical Net IRR and Net MOIC across 3+ TCV fund vintages in a single summary table. One-per-document.
- **Do NOT trigger on:** single-fund performance slides, gross-only performance, investment-level performance tables

### 17. appendix_growth_fund_investments
- **Placement:** footnote
- **Trigger:** ONLY when a slide explicitly contains "See Appendix for the complete list" or a direct equivalent
- **Do NOT trigger on:** slides showing partial data without explicitly directing to an appendix

### 18. forecasts_and_estimates
- **Placement:** back
- **Trigger:** ONLY when a slide shows explicit numerical forecasts for future periods — specific projected market size with a future year, target fund IRR, projected ARR, or named company financial forecast
- **Do NOT trigger on:** general forward-looking language ("we believe", "we expect") without specific numeric projections, historical performance slides

---

## How to Update Rules with New Documents

1. Add new "gold star" PDFs to `uploads/`
2. Re-run the Docling extraction script to update `uploads/extracted_text.json`
3. Give a new Claude instance this METHODOLOGY.md file along with the extracted text
4. Ask Claude to: "Using the conservative rules philosophy in this document, analyze the new documents and update rules.json. Tighten any rules that would overflag. Add 'Do NOT trigger on...' guardrails to any rule that lacks them."
5. Review the updated rules before deploying

---

## Prompt to Give a New Claude Instance

If you need to rebuild or extend this system from scratch on a new computer, give Claude this exact prompt after sharing this document:

> "I'm working on a disclosure rationale tool for financial documents. I have a methodology document that explains the conservative rules philosophy — the core principle is to underflag rather than overflag. Please read the METHODOLOGY.md file I'm sharing and use it to help me [analyze new documents / update rules / build the tool]. The most important thing is that every rule must have explicit 'Do NOT trigger on...' guardrails and must only fire on specific, unambiguous evidence — never on broad topics or themes."
