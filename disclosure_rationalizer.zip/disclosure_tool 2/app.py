from flask import Flask, render_template, request, jsonify, send_file
import pandas as pd
import json
import os
import io

app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/upload-disclosures", methods=["POST"])
def upload_disclosures():
    file = request.files.get("file")
    if not file:
        return jsonify({"error": "No file provided"}), 400

    try:
        # Save to disk so we can use it later for analysis
        excel_path = os.path.join(UPLOAD_FOLDER, "disclosures.xlsx")
        file.save(excel_path)
        df = pd.read_excel(excel_path)
        # Return columns and rows so the frontend can display them
        columns = df.columns.tolist()
        rows = df.where(pd.notnull(df), None).to_dict(orient="records")
        return jsonify({"columns": columns, "rows": rows})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/upload-documents", methods=["POST"])
def upload_documents():
    files = request.files.getlist("files")
    if not files:
        return jsonify({"error": "No files provided"}), 400

    saved = []
    for f in files:
        path = os.path.join(UPLOAD_FOLDER, f.filename)
        f.save(path)
        saved.append(f.filename)

    return jsonify({"saved": saved})


@app.route("/rules", methods=["GET"])
def get_rules():
    rules_path = os.path.join(UPLOAD_FOLDER, "rules.json")
    if not os.path.exists(rules_path):
        return jsonify({})
    with open(rules_path) as f:
        return jsonify(json.load(f))


@app.route("/download-rules", methods=["GET"])
def download_rules():
    tier = request.args.get("tier", "baseline")
    excel_path = os.path.join(UPLOAD_FOLDER, "disclosures.xlsx")
    rules_path = os.path.join(UPLOAD_FOLDER, "rules.json")

    if not os.path.exists(excel_path) or not os.path.exists(rules_path):
        return jsonify({"error": "Missing disclosures or rules file"}), 400

    df = pd.read_excel(excel_path)
    with open(rules_path) as f:
        all_rules = json.load(f)

    tier_rules = all_rules.get(tier, all_rules.get("baseline", {}))

    rows = []
    for _, row in df.iterrows():
        name = row.get("name", "")
        rule_obj = tier_rules.get(name, {})
        rows.append({
            "Disclosure Name":     row.get("display_name", name),
            "Disclosure Language": row.get("disclosure", ""),
            "Rule":                rule_obj.get("rule", "No rule available"),
            "Placement":           rule_obj.get("placement", ""),
            "Tier":                tier
        })

    out_df = pd.DataFrame(rows)
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        out_df.to_excel(writer, index=False, sheet_name="Rationales")
        ws = writer.sheets["Rationales"]
        for col in ws.columns:
            max_len = max((len(str(cell.value)) if cell.value else 0) for cell in col)
            ws.column_dimensions[col[0].column_letter].width = min(max_len + 4, 80)
    output.seek(0)

    filename = f"Rationales_{tier}.xlsx"
    return send_file(output, as_attachment=True, download_name=filename,
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


if __name__ == "__main__":
    app.run(debug=True)
