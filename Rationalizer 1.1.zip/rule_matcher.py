"""
Universal rule matcher for financial disclosure rationale tool.
Matches any organization's disclosure language to rule templates using keyword scoring.
"""

RULE_TEMPLATES = {
    "gross_returns": {
        "keywords": [
            "gross irr", "gross moic", "gross multiple", "gross return",
            "gross realized", "gross unrealized", "before fees", "before management fee",
            "before carried interest", "gross proceeds", "gross performance",
            "gross investment", "gross tvm"
        ],
        "placement": "footnote",
        "baseline_rule": "Trigger ONLY when a slide shows an explicit labeled column or row with gross return metrics (Gross IRR, Gross MOIC, Gross Multiple, or equivalent) alongside actual numeric values. Do NOT trigger on prose discussion of returns, general performance commentary, or non-performance use of the word 'gross'.",
        "triggers": ["Gross IRR", "Gross MOIC", "Gross Multiple", "Gross Return", "Gross Realized"]
    },
    "net_returns": {
        "keywords": [
            "net irr", "net moic", "net multiple", "net return", "net dpi",
            "net performance", "after fees", "after management fee", "after carried interest",
            "net tvm", "net realized", "net unrealized", "lp returns", "lp performance"
        ],
        "placement": "footnote",
        "baseline_rule": "Trigger ONLY when a slide shows both fund size and net performance metrics (Net IRR, Net MOIC, Net DPI) in the same table, where the disclosure clarifies what is and is not reflected in the figures. Do NOT trigger on gross-only slides or fund size without performance metrics.",
        "triggers": ["Net IRR", "Net MOIC", "Net DPI", "Net Return", "Net Multiple"]
    },
    "past_performance": {
        "keywords": [
            "past performance", "historical performance", "track record", "prior returns",
            "historical returns", "historical irr", "prior fund", "legacy fund",
            "performance history", "historical track record", "prior performance"
        ],
        "placement": "footnote",
        "baseline_rule": "Trigger ONLY on the primary multi-fund track record table showing historical net returns across 3 or more fund vintages in a single summary table. Do NOT trigger on single-fund performance slides, gross-only performance, or investment-level performance tables.",
        "triggers": ["historical performance", "track record", "prior fund returns", "past performance"]
    },
    "forecasts": {
        "keywords": [
            "forecast", "projection", "projected", "target irr", "target return",
            "expected return", "anticipated", "future performance", "forward-looking",
            "target moic", "expected irr", "projected market size", "target arr",
            "projected revenue", "estimated", "future fund", "target dpi"
        ],
        "placement": "back",
        "baseline_rule": "Trigger ONLY when a slide shows explicit numerical forecasts for future periods — specific projected market size with a future year, target fund IRR, projected ARR, or named company financial forecast. Do NOT trigger on general forward-looking language ('we believe', 'we expect') without specific numeric projections, or on historical performance slides.",
        "triggers": ["target IRR", "projected return", "forecast", "target MOIC", "projected ARR"]
    },
    "illustrative_case_study": {
        "keywords": [
            "case study", "company spotlight", "featured investment", "illustrative",
            "illustrative example", "example investment", "portfolio spotlight",
            "investment spotlight", "company profile", "investment profile",
            "representative investment", "example company"
        ],
        "placement": "footnote",
        "baseline_rule": "Trigger ONLY on single-company case study or spotlight slides explicitly labeled 'Case Study', 'Company Spotlight', 'Featured Investment', or equivalent. Do NOT trigger on general portfolio tables, logo grids, or passing mentions of a single company.",
        "triggers": ["Case Study", "Company Spotlight", "Featured Investment", "Illustrative Example"]
    },
    "benchmarks_indices": {
        "keywords": [
            "benchmark", "index", "russell 2000", "s&p 500", "nasdaq", "pme",
            "public market equivalent", "compared to index", "vs. index", "relative to",
            "index comparison", "benchmark comparison", "msci", "cambridge associates",
            "preqin", "versus benchmark"
        ],
        "placement": "footnote",
        "baseline_rule": "Trigger ONLY when a slide shows an explicit side-by-side comparison of fund returns vs. a named index or benchmark with actual numeric figures for both. Do NOT trigger on passing mentions of an index, benchmark references without numerical comparison, or general market commentary.",
        "triggers": ["vs. S&P 500", "vs. Russell 2000", "PME", "benchmark comparison", "index comparison"]
    },
    "esg_sustainability": {
        "keywords": [
            "esg", "sustainability", "environmental", "social", "governance",
            "responsible investment", "impact", "climate", "carbon", "diversity",
            "esg factors", "sustainability factors", "esg analysis", "esg assessment",
            "esg criteria", "sustainable investing", "responsible investing"
        ],
        "placement": "back",
        "baseline_rule": "Trigger ONLY when a slide explicitly describes ESG or sustainability factors as part of the investment analysis or decision-making process with specific claims. Do NOT trigger on ESG as a portfolio theme, ESG as a market trend, or passing references to sustainability.",
        "triggers": ["ESG factors", "sustainability analysis", "ESG assessment", "ESG criteria"]
    },
    "ai_technology": {
        "keywords": [
            "artificial intelligence", "machine learning", "ai", "ml", "algorithm",
            "data science", "proprietary technology", "sourcing technology",
            "technology platform", "data-driven", "quantitative", "predictive analytics",
            "natural language processing", "nlp", "deep learning"
        ],
        "placement": "back",
        "baseline_rule": "Trigger ONLY when a slide explicitly describes AI or machine learning as a component of the firm's investment sourcing, screening, or monitoring process with specific claims about what the technology does. Do NOT trigger on AI as a portfolio theme, AI as a market trend, or AI as a characteristic of a portfolio company.",
        "triggers": ["AI sourcing", "machine learning", "proprietary algorithm", "data-driven sourcing"]
    },
    "hypothetical_performance": {
        "keywords": [
            "hypothetical", "simulated", "back-tested", "backtested", "pro forma performance",
            "model portfolio", "illustrative performance", "hypothetical return",
            "simulated return", "extracted return", "projected performance",
            "hypothetical irr", "hypothetical moic"
        ],
        "placement": "back",
        "baseline_rule": "Trigger ONLY when a slide presents hypothetical, simulated, or back-tested performance figures explicitly labeled as such. Do NOT trigger on actual historical performance, forward-looking projections without historical simulation, or illustrative case studies.",
        "triggers": ["hypothetical performance", "simulated returns", "back-tested", "pro forma performance"]
    },
    "liquidity_distributions": {
        "keywords": [
            "liquidity", "dpi", "distributions", "realized", "distribution yield",
            "cash on cash", "distributions to paid-in", "realized proceeds",
            "exit", "monetization", "liquidity events", "total distributions",
            "realized value", "distribution rate"
        ],
        "placement": "footnote",
        "baseline_rule": "Trigger ONLY on slides showing a table of liquidity events or distributions explicitly filtered to a subset (e.g., 'Select Liquidity Events', 'Total Distributions > $X'), where the heading makes clear it is not a complete list. Do NOT trigger on general mentions of liquidity, fund-level DPI figures, or complete distribution schedules.",
        "triggers": ["Select Liquidity", "Total Distributions", "Liquidity Events", "Realized Proceeds"]
    },
    "term_sheets": {
        "keywords": [
            "term sheet", "term sheets", "deal terms", "investment terms",
            "proposed terms", "indicative terms", "preliminary terms",
            "non-binding", "subject to negotiation"
        ],
        "placement": "back",
        "baseline_rule": "Trigger ONLY on slides that explicitly display term sheet content or deal terms, labeled as term sheets or indicative/proposed terms. Do NOT trigger on general deal process descriptions or investment strategy slides.",
        "triggers": ["term sheet", "proposed terms", "indicative terms", "deal terms"]
    },
    "pipeline_funnel": {
        "keywords": [
            "pipeline", "deal flow", "funnel", "sourcing", "deal sourcing",
            "investment pipeline", "opportunity set", "screened", "evaluated",
            "reviewed", "sourced", "deal count", "opportunities reviewed"
        ],
        "placement": "footnote",
        "baseline_rule": "Trigger ONLY on slides showing an explicit funnel or pipeline diagram with labeled stages and numeric company counts at each stage. Do NOT trigger on prose descriptions of sourcing process, general strategy slides, or single-number deal flow statistics.",
        "triggers": ["pipeline funnel", "deal flow stages", "opportunities screened", "sourcing funnel"]
    },
    "advisors_partners": {
        "keywords": [
            "operating partner", "senior advisor", "executive advisor", "advisory board",
            "venture partner", "special advisor", "operating executive",
            "executive network", "operating team", "advisor roster", "partner network"
        ],
        "placement": "back",
        "baseline_rule": "Trigger ONLY on slides explicitly dedicated to listing Operating Partners, Senior Advisors, or Executive Advisors as a named roster or directory. Do NOT trigger on brief mentions of an advisor by name or passing advisory references.",
        "triggers": ["Operating Partners", "Senior Advisors", "Executive Advisors", "Advisory Board"]
    },
    "company_logos": {
        "keywords": [
            "logo", "logos", "portfolio companies", "portfolio overview",
            "company grid", "investment grid", "logo grid", "portfolio grid",
            "current portfolio", "select portfolio", "representative portfolio"
        ],
        "placement": "back",
        "baseline_rule": "Trigger ONLY on slides displaying a grid or collection of multiple company logos as the primary visual content (portfolio overview, logo grid, fund summary with logos). Do NOT trigger on a single company logo appearing incidentally in a case study header or cover slide.",
        "triggers": ["logo grid", "portfolio companies", "portfolio overview logos"]
    },
    "rounding": {
        "keywords": [
            "rounding", "may not sum", "due to rounding", "rounded to",
            "figures may not", "totals may not", "numbers may not sum",
            "approximated", "rounded figures"
        ],
        "placement": "footnote",
        "baseline_rule": "Trigger ONLY on financial tables with a visible Total row or column where individual line items are summed, at a precision level where rounding discrepancies would be noticeable. Do NOT trigger on charts, prose, or tables without explicit sum totals.",
        "triggers": ["may not sum due to rounding", "figures are rounded", "totals may not sum"]
    },
    "aum": {
        "keywords": [
            "assets under management", "aum", "capital raised", "total capital",
            "fund size", "committed capital", "total aum", "firm aum",
            "aggregate capital", "capital managed", "regulatory aum"
        ],
        "placement": "footnote",
        "baseline_rule": "Trigger ONLY on slides showing a specific AUM or capital figure where the basis of calculation (regulatory vs. discretionary, fee-paying vs. total) requires clarification. Do NOT trigger on passing references to fund size or general scale descriptions.",
        "triggers": ["Assets Under Management", "AUM", "committed capital", "capital raised"]
    },
    "market_commentary": {
        "keywords": [
            "market commentary", "market outlook", "sector research", "industry research",
            "market trends", "macroeconomic", "macro", "market opportunity",
            "industry dynamics", "competitive landscape", "market size", "tam",
            "total addressable market", "sector analysis", "market analysis"
        ],
        "placement": "back",
        "baseline_rule": "Trigger ONLY when a slide presents specific third-party market data, industry research, or sector analysis with attribution to an external source and specific numeric claims. Do NOT trigger on general qualitative market commentary or high-level thematic observations.",
        "triggers": ["market size", "industry research", "sector analysis", "market data"]
    },
    "investment_objectives": {
        "keywords": [
            "investment objective", "investment strategy", "fund objective",
            "investment mandate", "target return", "investment thesis",
            "strategy overview", "fund strategy", "investment focus",
            "target investments", "portfolio construction"
        ],
        "placement": "footnote",
        "baseline_rule": "Trigger ONLY on slides that explicitly state the fund's investment objectives or mandate as a formal description, particularly where specific return targets or portfolio construction parameters are stated. Do NOT trigger on general strategy overview slides or investment theme discussions.",
        "triggers": ["investment objectives", "fund mandate", "target return profile", "investment strategy"]
    },
    "not_representative": {
        "keywords": [
            "not representative", "select investments", "selected investments",
            "subset", "representative sample", "illustrative subset",
            "not all investments", "excludes", "filtered", "screened",
            "criteria", "fmv", "fair market value threshold"
        ],
        "placement": "footnote",
        "baseline_rule": "Trigger ONLY on slides showing a filtered subset of portfolio companies where the filter criteria are explicitly stated (e.g., 'Active investments with FMV > $50M', 'Investments made after 2020'). Do NOT trigger on slides showing all investments in a fund, case study slides, or slides with no explicit filter stated.",
        "triggers": ["Select Investments", "not representative of all investments", "filtered subset", "excludes certain investments"]
    },
    "pro_forma": {
        "keywords": [
            "pro forma", "pro-forma", "adjusted", "normalized", "as adjusted",
            "non-gaap", "non gaap", "adjusted ebitda", "adjusted revenue",
            "pro forma revenue", "run rate", "annualized", "proforma"
        ],
        "placement": "footnote",
        "baseline_rule": "Trigger ONLY on slides presenting pro-forma, adjusted, or normalized financial metrics that differ from GAAP or reported figures, where the adjustment methodology requires explanation. Do NOT trigger on general financial tables with no adjustments, or on slides using 'adjusted' in a non-financial context.",
        "triggers": ["pro forma", "as adjusted", "normalized metrics", "non-GAAP"]
    },
    "third_party_data": {
        "keywords": [
            "third party", "third-party", "external data", "source:", "sourced from",
            "data source", "provided by", "according to", "based on data",
            "external source", "public data", "bloomberg", "pitchbook", "preqin",
            "factset", "sp global", "morningstar"
        ],
        "placement": "back",
        "baseline_rule": "Trigger ONLY when a slide presents data, statistics, or analysis sourced from a named third party, where the reliability and independence of that source requires disclosure. Do NOT trigger on general market commentary without specific third-party attribution.",
        "triggers": ["third-party data", "sourced from", "external data provider", "data source"]
    }
}


def generate_tiers(template_name, template):
    placement = template["placement"]
    base_rule = template["baseline_rule"]
    triggers = template["triggers"]
    topic = triggers[0] if triggers else template_name.replace("_", " ")

    return {
        "most_exclusive": {
            "placement": placement,
            "rule": f"Trigger ONLY when ALL THREE of the following are simultaneously present: (1) {topic} is explicitly labeled on the slide, (2) specific numeric values are shown in direct association with that label, AND (3) a corroborating element is present (e.g., a corresponding net metric, a footnote reference, or an explicit table header). Do NOT trigger unless all three conditions are unambiguously met.",
            "triggers": triggers
        },
        "exclusive": {
            "placement": placement,
            "rule": f"{base_rule} Additionally, at least one corroborating element must be visible on the same slide (e.g., a labeled table header, a corresponding metric, or an explicit footnote reference).",
            "triggers": triggers
        },
        "baseline": {
            "placement": placement,
            "rule": base_rule,
            "triggers": triggers
        },
        "inclusive": {
            "placement": placement,
            "rule": f"Trigger when the slide discusses {topic} or closely related concepts with any supporting numerical data or context. May trigger on summary slides, overview pages, or fund snapshots that reference these metrics even without a dedicated labeled column.",
            "triggers": triggers
        },
        "most_inclusive": {
            "placement": placement,
            "rule": f"Trigger whenever the slide mentions {topic} or any conceptually related term in any context, including passing references in headers, footnotes, narrative prose, or visual elements.",
            "triggers": triggers
        }
    }


def match_disclosure_to_template(text):
    """Score each rule template against the disclosure text. Return best match name or None."""
    if not text:
        return None
    text_lower = text.lower()
    best_match = None
    best_score = 0
    for template_name, template in RULE_TEMPLATES.items():
        score = sum(1 for kw in template["keywords"] if kw in text_lower)
        if score > best_score:
            best_score = score
            best_match = template_name
    return best_match if best_score > 0 else None


def build_rules_for_disclosures(df):
    """
    Given a disclosures dataframe, generate a full 5-tier rules dict
    keyed by each disclosure's 'name' field.
    """
    rules = {t: {} for t in ["baseline", "exclusive", "most_exclusive", "inclusive", "most_inclusive"]}

    for _, row in df.iterrows():
        name = str(row.get("name", "") or "").strip()
        if not name:
            continue

        disclosure_language = str(row.get("disclosure", "") or "")
        display_name = str(row.get("display_name", name) or "")

        # Match against disclosure language first, then display name
        template_name = match_disclosure_to_template(disclosure_language)
        if not template_name:
            template_name = match_disclosure_to_template(display_name)

        if template_name:
            template = RULE_TEMPLATES[template_name]
            tiered = generate_tiers(template_name, template)
            for tier in rules:
                rules[tier][name] = tiered[tier]

    return rules
