#!/bin/bash

echo ""
echo "================================================"
echo "   Rationalizer — Install & Launch"
echo "================================================"
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed."
    echo "   Please install it from https://www.python.org/downloads/ and try again."
    exit 1
fi

echo "✅ Python 3 found: $(python3 --version)"
echo ""
echo "📦 Installing dependencies (this may take a few minutes)..."
echo ""

pip3 install flask pandas openpyxl docling anthropic --quiet

if [ $? -ne 0 ]; then
    echo ""
    echo "❌ Something went wrong during installation."
    echo "   Try running: pip3 install flask pandas openpyxl docling anthropic"
    exit 1
fi

echo ""
echo "✅ All dependencies installed."
echo ""
echo "🚀 Launching Rationalizer..."
echo ""
echo "   Open your browser and go to: http://localhost:5000"
echo "   Press Ctrl+C to stop the app."
echo ""

cd "$(dirname "$0")"
python3 app.py
