# Rationalizer — Full Methodology & System Guide

## Purpose

The Rationalizer is a web-based tool for financial compliance teams. It takes an organization's disclosure language (from Excel) and their "gold star" client documents (PDFs), and generates placement rules that tell a downstream disclosure agent when and where each disclosure should appear.

This document captures everything a new Claude instance needs to know to understand, reproduce, extend, or debug the system faithfully.

---

## System Architecture

### Files

| File | Purpose |
|------|---------|
| `app.py` | Flask backend — all API endpoints |
| `rule_matcher.py` | Universal keyword-based rule generator — works for any org |
| `templates/index.html` | Full single-page frontend (HTML + CSS + JS) |
| `METHODOLOGY.md` | This file — the source of truth for all logic |
| `install_and_run.sh` | One-click install and launch script |
| `uploads/disclosures.xlsx` | The org's disclosure language (uploaded by user) |
| `uploads/rules.json` | Generated 5-tier placement rules (keyed by disclosure name) |
| `uploads/intake_form.json` | Parsed intake form config — dimensions and their options |
| `uploads/intake_tags.json` | Per-disclosure intake tag suggestions (include/exclude, keyed by disclosure name) |
| `uploads/document_tags.json` | Maps uploaded PDF filenames to their multi-dimensional intake tags |
| `uploads/extracted_text.json` | Extracted text from uploaded PDFs (via Docling) |

### Tech stack
- **Backend:** Python / Flask
- **Data:** pandas, openpyxl
- **PDF extraction:** Docling (`pip3 install docling`)
- **AI generation:** Local `claude -p` CLI subprocess calls (Claude Code must be installed)
- **Frontend:** Vanilla JS, no framework

---

## Core Philosophy: Underflag, Don't Overflag

**The single most important principle:** It is better to MISS a disclosure placement than to recommend one incorrectly.

Why: If the tool overflags (recommends disclosures where they aren't needed), users stop trusting it. A false positive erodes confidence faster than a false negative. The rules must be conservative — they should only fire when the evidence is unambiguous and specific.

**When writing or updating rules, always ask:**
- "Could this trigger fire on a slide where the disclosure is NOT actually needed?" If yes, tighten it.
- "Am I triggering on a topic/theme, or on specific concrete evidence?" Only trigger on concrete evidence.
- "Does this rule have guardrails?" Every rule should say what it does NOT trigger on.

---

## The Excel — Disclosure Language Input

The user uploads an Excel file with their org's disclosure language. The tool expects these columns (auto-detected by the column mapper):

| Column | Purpose |
|--------|---------|
| `display_name` | Human-readable name shown in the UI (e.g. "Gross Returns — All Strategies") |
| `disclosure` | The full legal/regulatory disclosure text |
| `name` | Snake_case key used to look up rules (e.g. `gross_returns_all_strategies`). Auto-generated from `display_name` via `slugify()` if blank. |
| `intake_tag` / `metadata_tags` | Document-type tag for pre-filtering (see Intake Tags section) |

### Auto-slugification
If the `name` column is blank, the tool automatically generates it from `display_name` using `slugify()`:
- Lowercased, unicode-normalized, spaces → underscores, truncated to 80 chars
- Example: "Gross Returns — All Strategies" → `gross_returns_all_strategies`
- This slug becomes the key for looking up rules in `rules.json`

### Column mapper
The UI includes a column mapper so users can tell the tool which columns map to which fields. It auto-guesses based on common column names. Users can override manually.

---

## Rule Structure

Every rule in `uploads/rules.json` has this structure:

```json
{
  "disclosure_name_key": {
    "placement": "footnote" or "back",
    "rule": "Plain English description of when to trigger. Must include 'Do NOT trigger on...' guardrails.",
    "triggers": ["specific phrase 1", "specific phrase 2"]
  }
}
```

**Placement definitions:**
- `footnote` — disclosure appears on the same page as the trigger (page footnote)
- `back` — disclosure appears in the back/endnotes/appendix of the document

**Placement informs trigger scope:**
The position field is not just metadata — it tells you *where to look for the trigger evidence*:
- **Same page / footnote** → the root cause of the disclosure firing is co-located with it on the same page. Triggers should be slide-level or page-level: "this slide contains X", "a table on this page shows Y". The disclosure only fires when the trigger is present on that specific page.
- **Back of document** → the disclosure applies to the document broadly and appears once at the end. Triggers should be document-level: "the document discusses X anywhere", "any slide in the document shows Y". The trigger could be anywhere in the doc.

### The 5-Tier Sensitivity System

Rules exist at 5 sensitivity tiers. The user selects a tier via the dial in the UI. From most conservative to most permissive:

| Tier | Behavior |
|------|---------|
| `most_exclusive` | Fires ONLY when all three are present: explicit label + numeric values + corroborating element |
| `exclusive` | Baseline rule + requires at least one corroborating element on the same slide |
| `baseline` | The core conservative rule — fires only on specific, unambiguous evidence |
| `inclusive` | Fires on related concepts with any supporting data, including summary/overview slides |
| `most_inclusive` | Fires whenever the topic or any related term appears in any context |

All 5 tiers are derived programmatically from the baseline rule. The baseline is the only one written by hand (or generated by Claude). The other 4 are derived by wrapping the baseline rule with more or less restrictive language.

---

## How Rules Are Generated

### Method 1: Universal keyword matching (instant, on upload)

`rule_matcher.py` contains `RULE_TEMPLATES` — 20+ pre-built financial disclosure categories, each with:
- A keyword list (used to match against disclosure language)
- A `placement` value
- A `baseline_rule` string
- A `triggers` list of specific phrases

When the user uploads their Excel, `build_rules_for_disclosures()` automatically matches each disclosure against these templates using keyword scoring and generates a full 5-tier rules set. This happens instantly, no Claude call needed.

This works for **any organization** — it matches against the disclosure language, not org-specific knowledge.

### Method 2: Claude-generated rules (via "Generate Rationales" button)

For higher quality, org-specific rules, the user can click "✦ Generate Rationales." This:
1. Loads the disclosures from Excel (including the `position` column if present)
2. Loads extracted document text from `uploads/extracted_text.json` (if available)
3. Loads `METHODOLOGY.md` (this file) to give Claude the conservative rules philosophy
4. Loads `uploads/intake_form.json` (if available) to give Claude the intake form dimensions
5. Loads `uploads/document_tags.json` (if available) so Claude knows which uploaded docs are which type
6. Calls `claude -p` as a subprocess with a prompt containing all of the above
7. Parses the JSON output — Claude returns baseline rules only
8. Derives all 5 tiers programmatically from the baseline
9. Saves to `uploads/rules.json`
10. If an intake form is loaded, also parses a second JSON block from Claude's output containing per-disclosure intake tag suggestions, saves to `uploads/intake_tags.json`

The prompt instructs Claude to follow the conservative philosophy: every rule must have explicit "Do NOT trigger on..." guardrails and must only fire on specific, concrete evidence.

**Position column and rule scope:** The `position` column from the Excel is passed to Claude and determines how triggers are scoped:
- Same page / footnote → triggers must be page-level (co-located with the disclosure)
- Back of document → triggers can be document-level (anywhere in the doc)

**Artifact Rule vs Document Rule:** The UI displays a badge on each disclosure's rule box:
- **Artifact Rule** (amber) — same-page / footnote disclosures. The trigger is on the same page/slide as the disclosure.
- **Document Rule** (green) — back-of-document disclosures. The trigger applies to the document broadly.

---

## Generate Names Feature

If `display_name` is blank for any disclosure, a "✦ Generate Names" button appears. Clicking it:
1. Finds all disclosures missing a `display_name`
2. Calls `claude -p` with the disclosure language
3. Claude returns a JSON array of professional title-case names (5–10 words each)
4. Names are written back to `disclosures.xlsx`

---

## Intake Tags — Document Pre-Filtering

### What intake tags are

Intake tags are labels applied to **client documents** (PDFs) to categorize what kind of document they are. They are NOT labels for disclosures. A tag describes a document, not a rule.

The purpose of intake tags is pre-filtering: before the disclosure agent runs its rule-matching logic against a document, it first checks the document's tag. If the document type is outside the scope of a given disclosure, that disclosure is skipped entirely — no rule matching needed.

This prevents noise. Instead of running every disclosure against every document (which produces false positives), you narrow the field first by document type, then do fine-grained content matching within the filtered set.

### How a disclosure uses tags (in the downstream LEAP app)

Each disclosure in the disclosure management system can be configured with:
- **ONLY fire on** documents tagged X, Y, or Z
- **NEVER fire on** documents tagged X

The Rationalizer tool does not apply these rules — it helps generate and understand them. The actual tag-based filtering happens in the downstream disclosure agent.

### Two-bucket tag taxonomy

Tags are divided into two orthogonal dimensions:

1. **Type of Material** — what kind of document is it?
   - Examples: `fact_sheet`, `pitch_deck`, `lp_advisory_committee_materials`, `due_diligence_questionnaire`, `investment_memorandum`, `quarterly_report`
   - Must read as a document/material type — always include a word like `_deck`, `_report`, `_memo`, `_materials`, `_sheet`, `_questionnaire` where needed
   - BAD: `lp_advisory_committee` (sounds like an event, not a document)
   - GOOD: `lp_advisory_committee_materials` (clearly a type of material)

2. **Theme of Material** — what investment strategy or asset class does it cover?
   - Examples: `credit`, `private_equity`, `all_strategies`, `real_estate`, `growth_equity`
   - These are strategy/asset class labels, NOT document formats

A single document might be tagged with one from each bucket (e.g. `fact_sheet` + `credit`). The two dimensions are independent.

### Where tags come from

**Option A — Already in Excel:** If the org's Excel has a column like `metadata_tags`, `intake_tag`, or `artifact_tags`, the user selects it in the "Intake Tag column" dropdown. The tool reads unique values from that column and uses them as the tag vocabulary.

**Option B — Generate from scratch:** If no tags exist, the user clicks "✦ Suggest Intake Tags." Claude analyzes the disclosure language and any extracted document text, then suggests 3–6 tags per bucket. The user clicks "Use These Tags" to adopt them.

### Intake form upload

If the org has an intake form config Excel (e.g. downloaded from LEAP), the user uploads it in the third upload box. The tool parses it into a dimensions map:

```json
{
  "Asset Type": ["Pitch Deck", "Overview Deck", "Report", "DDQ", ...],
  "Distribution": ["External", "Internal", ...],
  "Theme or Topic": ["Private Equity", "Credit", ...],
  "Audience": ["Client (All)", "Potential Client", "Internal", ...]
}
```

Only multi-select / checkbox / radio fields are parsed — date and text fields are ignored. Saved to `uploads/intake_form.json`.

### Multi-dimensional document tagging

Each uploaded PDF gets an **Add Tags?** button. Clicking it opens a compact panel with one dropdown per intake form dimension. The user selects the appropriate value for each dimension. Tags are saved to `uploads/document_tags.json` as a dimension map per file:

```json
{
  "pitch_deck_Q3.pdf": {
    "Asset Type": "Pitch Deck",
    "Distribution": "External",
    "Theme or Topic": "Private Equity",
    "Audience": "Potential Client"
  }
}
```

The **Add Tags?** button only appears after the intake form has been uploaded.

### Per-disclosure intake tag suggestions

When Generate Rationales runs with an intake form loaded, Claude also outputs evidence-based tag suggestions for each disclosure. These appear in the disclosure card under **Suggested Tags** with two possible modes:

- **Recommend include** (teal) — Claude has seen this disclosure fire on documents of this type
- **Recommend NOT:** (red) — Claude has seen documents of this type and the disclosure was clearly absent

**Critical principle — evidence-based only, no assumptions:**
- Claude may only recommend a type if it has actual uploaded documents of that type to reason from
- "Recommend include" does NOT mean "only" — there may be other types Claude hasn't seen
- Never recommend a type (include or exclude) for which no uploaded documents exist

### Suggest Intake Tags (without intake form)

If no intake form is uploaded, the **✦ Suggest Intake Tags** button generates a general two-bucket vocabulary (Type of Material + Theme of Material) from the disclosure language alone. The user clicks "Use These Tags" to adopt them as the flat tag vocabulary for document tagging.

---

## PDF Text Extraction

Uses Docling to extract full text from uploaded PDFs:

```python
from docling.document_converter import DocumentConverter
converter = DocumentConverter()
result = converter.convert("path/to/document.pdf")
markdown_text = result.document.export_to_markdown()
```

Extracted text is saved to `uploads/extracted_text.json` and fed into the Generate Rationales prompt so Claude has document context when writing rules.

---

## The 18 Original Disclosures and Their Conservative Rules

These rules were derived from TCV's "gold star" finished documents. They are org-specific to TCV but serve as a reference for the level of specificity and conservatism required.

### 1. illustrative_purposes_only
- **Placement:** footnote
- **Trigger:** ONLY on single-company case study/spotlight slides explicitly labeled "Case Study", "Company Spotlight", or "Featured Investment"
- **Do NOT trigger on:** general portfolio tables, passing mentions of a company

### 2. gross_returns
- **Placement:** footnote
- **Trigger:** ONLY when a slide shows an explicit column/row labeled "Gross IRR", "Gross MOIC", "Gross Realized MOIC", "Gross Unrealized MOIC", or "Gross Total MOIC" with numeric values
- **Do NOT trigger on:** prose discussion of returns, non-performance use of "gross"

### 3. gross_gains_losses
- **Placement:** footnote
- **Trigger:** ONLY on the specific "Performance by Fund" table showing "Q[N] Gross Gain/(Loss)$" and "Q[N] Net Gain/(Loss)$" side by side across multiple funds
- **Do NOT trigger on:** general performance tables, fund snapshots, mentions of gains/losses

### 4. indices_and_benchmarks
- **Placement:** footnote
- **Trigger:** ONLY when a slide shows explicit side-by-side comparison of fund returns vs. a named index (Russell 2000, S&P 500, Nasdaq, PME) with actual numeric figures for both
- **Do NOT trigger on:** passing mentions of an index, references without numerical comparison

### 5. timeline_guarantee
- **Placement:** footnote
- **Trigger:** ONLY on single-company case study slides with an explicit "Value Creation Plan" or "Value Creation Initiatives" section listing specific milestones or timelines
- **Do NOT trigger on:** general portfolio tables, passing mentions of value creation, fund strategy slides

### 6. rounding
- **Placement:** footnote
- **Trigger:** ONLY on financial tables with a visible Total row/column where individual line items are summed, at a precision level where rounding discrepancies would be noticeable
- **Do NOT trigger on:** charts, prose, tables without explicit sum totals

### 7. partners_and_advisors
- **Placement:** back
- **Trigger:** ONLY on slides explicitly dedicated to listing Operating Partners, Senior Advisors, or Executive Advisors as a named roster or directory
- **Do NOT trigger on:** brief mentions of an advisor by name, passing advisory references

### 8. funnels_pipelines
- **Placement:** footnote
- **Trigger:** ONLY on slides showing an explicit funnel/pipeline diagram with labeled stages and numeric company counts at each stage
- **Do NOT trigger on:** prose descriptions of sourcing process, general strategy slides

### 9. summary_ddq
- **Placement:** back
- **Trigger:** ONLY on slides explicitly labeled as a DDQ summary, investment process overview, or decision-making process — typically in a due diligence questionnaire context
- **Do NOT trigger on:** general strategy slides, passing mentions of process

### 10. liquidity
- **Placement:** footnote
- **Trigger:** ONLY on slides showing a table of liquidity events explicitly filtered to a subset (e.g., "Select Liquidity", "Total Liquidity >$25M"), where the heading makes clear it is not a complete list
- **Do NOT trigger on:** general mentions of liquidity, fund-level DPI figures

### 11. advisor_network
- **Placement:** footnote
- **Trigger:** ONLY on slides displaying a curated named roster of Advisor Network members with names and titles, where the slide explicitly references "Advisor Network"
- **Do NOT trigger on:** passing mentions of advisors, single advisor named in context

### 12. gross_net_fund_metrics
- **Placement:** footnote
- **Trigger:** ONLY on fund snapshot/track record slides showing BOTH fund size AND net performance metrics (Net IRR, Net MOIC, Net DPI) in the same table, where fund size covers all parallel entities but performance reflects only fee-paying LP cash flows
- **Do NOT trigger on:** gross-only slides, net-only slides, fund size without performance

### 13. company_logos
- **Placement:** back
- **Trigger:** ONLY on slides displaying a grid or collection of multiple company logos as the primary visual content (portfolio overview, logo grid, fund summary with logos)
- **Do NOT trigger on:** single company logo appearing incidentally in a case study header or cover

### 14. ai_technology_assurances
- **Placement:** back
- **Trigger:** ONLY when a slide explicitly describes AI or ML as a component of the firm's investment sourcing, screening, or monitoring process with specific claims about what the technology does
- **Do NOT trigger on:** AI as a portfolio theme, AI as a market trend, AI as a characteristic of a portfolio company

### 15. not_representative_of_all_investments
- **Placement:** footnote
- **Trigger:** ONLY on slides showing a filtered subset of portfolio companies where the filter criteria are explicitly stated (e.g., "Active investments with FMV > $50M", "Investments made after 2020")
- **Do NOT trigger on:** slides showing all investments in a fund, case study slides, slides with no explicit filter stated

### 16. past_performance
- **Placement:** footnote
- **Trigger:** ONLY on the primary multi-fund track record table showing historical Net IRR and Net MOIC across 3+ fund vintages in a single summary table. One-per-document.
- **Do NOT trigger on:** single-fund performance slides, gross-only performance, investment-level performance tables

### 17. appendix_growth_fund_investments
- **Placement:** footnote
- **Trigger:** ONLY when a slide explicitly contains "See Appendix for the complete list" or a direct equivalent
- **Do NOT trigger on:** slides showing partial data without explicitly directing to an appendix

### 18. forecasts_and_estimates
- **Placement:** back
- **Trigger:** ONLY when a slide shows explicit numerical forecasts for future periods — specific projected market size with a future year, target fund IRR, projected ARR, or named company financial forecast
- **Do NOT trigger on:** general forward-looking language ("we believe", "we expect") without specific numeric projections, historical performance slides

---

## How to Update Rules with New Documents

1. Add new "gold star" PDFs to `uploads/`
2. Re-run the Docling extraction script to update `uploads/extracted_text.json`
3. Give a new Claude instance this METHODOLOGY.md file along with the extracted text
4. Ask Claude to: "Using the conservative rules philosophy in this document, analyze the new documents and update rules.json. Tighten any rules that would overflag. Add 'Do NOT trigger on...' guardrails to any rule that lacks them."
5. Review the updated rules before deploying

---

## Prompt to Give a New Claude Instance

If you need to rebuild or extend this system from scratch on a new computer, give Claude this exact prompt after sharing this document:

> "I'm working on a disclosure rationale tool for financial documents called the Rationalizer (v1.1). I have a methodology document (METHODOLOGY.md) that explains the full system — the conservative rules philosophy, the 5-tier sensitivity system, the intake form config, multi-dimensional document tagging, evidence-based intake tag suggestions, and how all the pieces fit together. Please read it carefully before helping me. The most important principles are: (1) underflag rather than overflag — every rule must have explicit 'Do NOT trigger on...' guardrails; (2) intake tags categorize documents, not disclosures; (3) the tool is designed to work for any financial organization, not just one specific firm; (4) intake tag suggestions must be evidence-based — only recommend types for which uploaded documents exist; (5) position/placement informs trigger scope — same-page disclosures get page-level triggers (Artifact Rule), back-of-doc disclosures get document-level triggers (Document Rule)."
