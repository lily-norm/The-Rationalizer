# Rationalizer — Setup Guide

A local web app that analyzes financial client documents (PDFs, PPTX, DOCX) and generates placement rules for legal disclosures. Built for compliance teams.

This README is written to be followed **literally**. Do not assume. If a command fails, run the verification step listed under it before continuing.

---

## What You Need Before You Start

You need **four** things installed and working. Verify each one before moving on. If any verification command fails, follow the install step next to it.

### 1. Python 3.9 or higher
Verify:
```bash
python3 --version
```
Expected output: `Python 3.9.x` or higher (3.10, 3.11, 3.12, 3.13 all fine).
If missing: install from https://www.python.org/downloads/ (macOS / Windows) or `sudo apt install python3` (Linux).

### 2. pip3 (Python package installer)
Verify:
```bash
pip3 --version
```
Expected output: a version string. If missing on macOS: `python3 -m ensurepip --upgrade`.

### 3. The Claude Code CLI
The app shells out to the `claude` command to generate rationales, names, and intake tag suggestions. **Without it, the three "✦" buttons in the UI silently do nothing.**

Verify:
```bash
claude --version
```
Expected output: a version string like `1.x.x`.

If missing, install with one of:
```bash
# macOS (recommended)
brew install claude

# Or via npm (any platform with Node.js)
npm install -g @anthropic-ai/claude-code
```

Then authenticate (one-time):
```bash
claude
```
This opens a browser to log in with your Anthropic / Claude account. After login, exit the interactive session with `Ctrl+C`. The auth token is cached.

Verify auth works:
```bash
echo "say hi" | claude -p "respond in one word"
```
Expected: a one-word response from Claude. If it errors with an auth message, repeat `claude` login.

### 4. Git (only if cloning from GitHub)
Verify:
```bash
git --version
```
If missing: `xcode-select --install` on macOS, or your OS's package manager.

---

## Getting the Code

```bash
git clone https://github.com/lily-norm/The-Rationalizer.git
cd The-Rationalizer
```

If you downloaded a ZIP instead, unzip it and `cd` into the resulting folder.

> **Warning about macOS ZIPs:** if you double-click a ZIP that you've already unzipped once, macOS will create a `The-Rationalizer 2/` folder. The space + number is *not* a version — it's a duplicate. Always use the folder without a numeric suffix unless you intentionally renamed it.

---

## Installing Python Dependencies

From inside the project folder, run **exactly** this command:

```bash
pip3 install flask pandas openpyxl pdfplumber python-pptx python-docx
```

This is what the code actually imports:
- `flask` — web server
- `pandas` + `openpyxl` — reads/writes the disclosure Excel file
- `pdfplumber` — extracts text from PDFs
- `python-pptx` — extracts text from PowerPoint files
- `python-docx` — extracts text from Word files

**Do not install `docling` or `anthropic`.** Older versions of this README mentioned them — the current code does not use either.

Verify the install:
```bash
python3 -c "import flask, pandas, openpyxl, pdfplumber, pptx, docx; print('all imports ok')"
```
Expected output: `all imports ok`.

---

## Running the App

From inside the project folder:

```bash
python3 app.py
```

Expected output ends with:
```
 * Running on http://127.0.0.1:5000
 * Restarting with stat
 * Debugger is active!
```

Leave that terminal window open — closing it stops the app. Open your browser to:

**http://localhost:5000**

You should see a dark-themed page titled **Rationalizer** with three drop zones.

### If port 5000 is already in use
You'll see `OSError: [Errno 48] Address already in use`. Find and stop the process:
```bash
lsof -iTCP:5000 -sTCP:LISTEN
kill <PID>
```
Or change the port — edit the last line of `app.py`:
```python
app.run(debug=True, port=5001)
```

---

## Using the App

1. **Drop the disclosure language Excel** into the right-side drop zone. Columns required: `Disclosure Name`, `Disclosure Text` (column names are case-insensitive; common synonyms like `name`, `display_name`, `disclosure`, `language` also work).
2. **Drop client PDFs** (and/or .pptx, .docx) into the left-side drop zone. These are your "gold-star" documents — finished examples where disclosures are already correctly placed.
3. **(Optional)** drop an intake form config Excel into the bottom zone if you want intake tag suggestions.
4. Click **✦ Generate Rationales**.

### Expected timing
- Upload + extraction: ~10–30 seconds depending on PDF size.
- Generate Rationales: **roughly 15 seconds to 3 minutes**, scaling with total extracted text. Claude reads the full corpus in one call; output is small JSON, so it's faster than you'd guess. A run that finishes in < 5 seconds is suspicious — see Troubleshooting.

---

## Troubleshooting

### "Generate Rationales" button doesn't exist
You're running an old version. Verify by checking:
```bash
grep -c "Generate Rationales" templates/index.html
```
Should return `3` or more. If it returns `0`, the file is the early version — pull the latest from GitHub.

### "Generate Rationales" returns instantly with no rules / empty output
The `claude` CLI is missing or not authenticated. Run the verification under "Prerequisites step 3" again.

### "Generate Rationales" finishes very fast (< 5 seconds) but rules appear
Likely you previously had a 20K-char truncation in `app.py:473`. Verify the current line reads `{raw}` (full corpus) and not `{raw[:20000]}`:
```bash
grep -n "raw\[" app.py
```
If you see `raw[:20000]`, change it to `raw`.

### `ModuleNotFoundError: No module named 'pdfplumber'` (or pptx, docx, flask, etc.)
Re-run the install command from "Installing Python Dependencies" above. If pip3 installs to a different Python than the one running `app.py`, use:
```bash
python3 -m pip install flask pandas openpyxl pdfplumber python-pptx python-docx
```

### "extraction error: ..." next to a document
The PDF is likely encrypted, password-protected, or an image-only scan (no text layer). pdfplumber can't extract text from image PDFs — you'd need an OCR step we don't currently support.

### `claude: command not found` when clicking Generate
The Flask app inherits the shell's PATH. If you installed `claude` after starting the app, **stop the app** (`Ctrl+C`) and restart it from a fresh terminal so it picks up the updated PATH.

### Page loads but drag-and-drop doesn't respond
Check the terminal running `app.py` for traceback errors. Browser console (F12) will show frontend errors. The most common cause is a corrupted upload — try refreshing the page.

---

## File Structure

```
The-Rationalizer/
├── app.py                  # Flask backend — all endpoints
├── rule_matcher.py         # Deterministic rule-building helpers
├── templates/
│   └── index.html          # Single-page UI
├── uploads/                # Created automatically on first run
│   ├── disclosures.xlsx        # Your disclosure language Excel
│   ├── extracted_text.json     # PDF/PPTX/DOCX text extraction (per run)
│   ├── document_tags.json      # Intake tags per document (per run)
│   ├── rules.json              # Generated rules (per run)
│   ├── intake_form.json        # Intake form dimensions (if uploaded)
│   └── *.pdf / *.pptx / *.docx # Your uploaded client documents
├── METHODOLOGY.md          # Full system explanation — read this for context
├── CLAUDE.md               # Instructions for Claude when opening the project
├── install_and_run.sh      # One-shot installer + launcher (macOS/Linux)
└── README.md               # This file
```

State persists between runs in `uploads/`. Every new document upload wipes prior `extracted_text.json`, `document_tags.json`, `rules.json`, and `intake_tags.json` — no stale-data carryover.

---

## How It Works (One-Paragraph Version)

When you click Generate Rationales, the app builds a prompt containing (a) the full extracted text of every uploaded document, (b) every row from your disclosures Excel, (c) the contents of `METHODOLOGY.md`, and (d) any intake form dimensions. It then runs `claude -p <prompt>` as a subprocess and parses the returned JSON into per-tier rules. **It does not match against any cached or pre-trained disclosure list** — every run is a fresh LLM analysis of the documents you just uploaded.

For the full methodology, conservative-rules philosophy, and 5-tier sensitivity system, read `METHODOLOGY.md`.
