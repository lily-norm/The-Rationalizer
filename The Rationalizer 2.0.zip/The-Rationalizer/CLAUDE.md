# Rationalizer — Instructions for Claude

If you (Claude) are opening this project to help a user run or modify it, follow these instructions literally. Do not assume — verify each step.

## To launch the app

1. Confirm Python 3.9+ is available:
   ```bash
   python3 --version
   ```
2. Confirm the `claude` CLI is available (the app shells out to it for rule generation):
   ```bash
   claude --version
   ```
   If missing, instruct the user to install via `brew install claude` (macOS) or `npm install -g @anthropic-ai/claude-code`, then run `claude` once to authenticate.
3. Install Python dependencies:
   ```bash
   pip3 install flask pandas openpyxl pdfplumber python-pptx python-docx
   ```
   Do **not** install `docling` or `anthropic` — neither is imported by the current code.
4. Check whether port 5000 is already in use:
   ```bash
   lsof -iTCP:5000 -sTCP:LISTEN
   ```
   If something is listening, ask the user before killing it.
5. Launch:
   ```bash
   python3 app.py
   ```
   Or use the one-shot installer: `chmod +x install_and_run.sh && ./install_and_run.sh`
6. Tell the user: "Rationalizer is running at http://localhost:5000."

## What this app does

The Rationalizer helps financial compliance teams generate placement rules for legal disclosures. The user uploads:
1. A disclosure language Excel (required)
2. "Gold-star" client documents — PDFs, PPTX, or DOCX (required for rule generation)
3. An intake form config Excel (optional)

When the user clicks **✦ Generate Rationales**, the app:
- Reads the full extracted text of every uploaded document (no truncation as of the May 21 fix — see `app.py:468–473`)
- Builds a single prompt containing the documents + disclosures + `METHODOLOGY.md` + intake form dimensions
- Subprocess-calls `claude -p <prompt>` and parses the returned JSON into per-tier rules

There is no cached disclosure library, no embedding store, no pattern-matching against past runs. Every click is a fresh LLM analysis.

Read `METHODOLOGY.md` for the conservative rules philosophy, 5-tier sensitivity system, Artifact Rule vs. Document Rule distinction, and intake tag logic.

## Common failure modes (and what to check first)

- **"Generate Rationales" button missing** → user is on an old version. Check `templates/index.html` for the string "Generate Rationales"; if absent, the file pre-dates the feature. They need to pull latest.
- **Button finishes in < 5 seconds with rules** → `app.py:473` likely still truncates `raw[:20000]`. Verify the line reads `{raw}` (full corpus). The bug was fixed May 21, 2026.
- **Button finishes instantly with empty / error output** → `claude` CLI is not installed or not authenticated. Test with `echo "hi" | claude -p "say one word"`.
- **`ModuleNotFoundError`** → pip3 may be installing to a different Python than the one running `app.py`. Use `python3 -m pip install <packages>` instead.
- **"extraction error" beside a PDF** → the PDF is likely an image-only scan or encrypted. pdfplumber can't OCR.
- **Port 5000 in use** → likely a previous instance is still running. Confirm with `lsof -iTCP:5000` before killing.

## What NOT to do

- Don't add `docling`, `anthropic`, or any LLM SDK to the dependencies. The current architecture is intentionally simple: subprocess to `claude` CLI.
- Don't change the truncation cap on `app.py:473` back to a small number. The full corpus must reach Claude for rules to be evidence-based across all documents.
- Don't commit the `uploads/` directory — `.gitignore` excludes it. It contains user data.
- Don't push to `origin/main` without the user's explicit say-so.
