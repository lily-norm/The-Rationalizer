#!/bin/bash
# Rationalizer — Install & Launch (macOS / Linux)
# For full setup instructions and Windows guidance, see README.md

set -e

echo ""
echo "================================================"
echo "   Rationalizer — Install & Launch"
echo "================================================"
echo ""

# --- 1. Python check -------------------------------------------------
if ! command -v python3 &> /dev/null; then
    echo "Python 3 is not installed."
    echo "Install it from https://www.python.org/downloads/ and re-run this script."
    exit 1
fi
echo "Python 3 found: $(python3 --version)"

# --- 2. claude CLI check ---------------------------------------------
if ! command -v claude &> /dev/null; then
    echo ""
    echo "WARNING: the 'claude' command was not found in your PATH."
    echo "The app will run, but the 'Generate Rationales', 'Generate Names',"
    echo "and 'Suggest Intake Tags' buttons will fail without it."
    echo ""
    echo "To install Claude Code:"
    echo "  brew install claude          # macOS (recommended)"
    echo "  npm install -g @anthropic-ai/claude-code   # any platform"
    echo ""
    echo "Then run 'claude' once to authenticate before using the buttons."
    echo ""
    read -r -p "Continue anyway? [y/N] " ans
    if [[ ! "$ans" =~ ^[Yy]$ ]]; then
        exit 1
    fi
else
    echo "claude CLI found: $(claude --version 2>/dev/null || echo 'version unknown')"
fi

# --- 3. Python dependencies -----------------------------------------
echo ""
echo "Installing Python dependencies (this may take a few minutes)..."
echo ""

pip3 install flask pandas openpyxl pdfplumber python-pptx python-docx

if [ $? -ne 0 ]; then
    echo ""
    echo "Dependency install failed. Try running manually:"
    echo "  python3 -m pip install flask pandas openpyxl pdfplumber python-pptx python-docx"
    exit 1
fi

echo ""
echo "All dependencies installed."

# --- 4. Launch -------------------------------------------------------
echo ""
echo "Launching Rationalizer..."
echo "Open your browser to: http://localhost:5000"
echo "Press Ctrl+C in this terminal to stop the app."
echo ""

cd "$(dirname "$0")"
python3 app.py
