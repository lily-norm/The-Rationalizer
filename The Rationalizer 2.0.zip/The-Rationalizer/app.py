from flask import Flask, render_template, request, jsonify, send_file
import pandas as pd
import json
import os
import io
import math
import re
import subprocess
import tempfile
from rule_matcher import build_rules_for_disclosures
import unicodedata

def slugify(text):
    text = str(text).lower().strip()
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"[^\w\s]", "", text)
    text = re.sub(r"\s+", "_", text)
    text = re.sub(r"_+", "_", text).strip("_")
    return text[:80]

def clean_row(row):
    return {k: (None if isinstance(v, float) and math.isnan(v) else v) for k, v in row.items()}

app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/upload-disclosures", methods=["POST"])
def upload_disclosures():
    file = request.files.get("file")
    if not file:
        return jsonify({"error": "No file provided"}), 400

    try:
        # Clear stale outputs — new disclosure list means a new job
        for stale in ["rules.json", "intake_tags.json"]:
            stale_path = os.path.join(UPLOAD_FOLDER, stale)
            if os.path.exists(stale_path):
                os.remove(stale_path)

        # Save to disk so we can use it later for analysis
        excel_path = os.path.join(UPLOAD_FOLDER, "disclosures.xlsx")
        file.save(excel_path)
        df = pd.read_excel(excel_path)
        df = df.dropna(how="all")

        # Auto-fill empty 'name' values from display_name slug
        if "name" not in df.columns:
            df["name"] = ""
        for i, row in df.iterrows():
            val = row.get("name", None)
            is_blank = val is None or (isinstance(val, float) and math.isnan(val)) or not str(val).strip()
            if is_blank:
                display = str(row.get("display_name", "") or "").strip()
                if display:
                    df.at[i, "name"] = slugify(display)
        df.to_excel(excel_path, index=False)

        # Auto-generate rules for this org's disclosures
        rules = build_rules_for_disclosures(df)
        rules_path = os.path.join(UPLOAD_FOLDER, "rules.json")
        with open(rules_path, "w") as f:
            json.dump(rules, f, indent=2)

        # Extract unique intake tags
        intake_tags = []
        if "intake_tag" in df.columns:
            intake_tags = sorted(set(
                str(v).strip() for v in df["intake_tag"].dropna()
                if str(v).strip() and str(v).strip().lower() != "nan"
            ))

        # Return columns, rows, and intake tags
        columns = df.columns.tolist()
        rows = [clean_row(r) for r in df.to_dict(orient="records")]
        return jsonify({"columns": columns, "rows": rows, "intake_tags": intake_tags})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/upload-intake-form", methods=["POST"])
def upload_intake_form():
    file = request.files.get("file")
    if not file:
        return jsonify({"error": "No file provided"}), 400
    try:
        import openpyxl as _xl
        wb = _xl.load_workbook(io.BytesIO(file.read()))
        ws = wb.active
        dimensions = {}
        current_dim = None
        for row in ws.iter_rows(values_only=True):
            if row[0]:
                input_type = str(row[2] or "").strip().lower()
                if any(k in input_type for k in ("select", "checkbox", "radio")):
                    current_dim = str(row[0]).strip()
                    dimensions[current_dim] = []
                    if row[3]:
                        dimensions[current_dim].append(str(row[3]).strip())
                else:
                    current_dim = None
            elif current_dim and row[3]:
                dimensions[current_dim].append(str(row[3]).strip())

        intake_path = os.path.join(UPLOAD_FOLDER, "intake_form.json")
        with open(intake_path, "w") as f:
            json.dump(dimensions, f, indent=2)
        return jsonify({"success": True, "dimensions": dimensions})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/upload-documents", methods=["POST"])
def upload_documents():
    import pdfplumber
    files = request.files.getlist("files")
    if not files:
        return jsonify({"error": "No files provided"}), 400

    # Clear all previous run state — every upload is a fresh job
    for stale in ["extracted_text.json", "document_tags.json", "rules.json",
                  "intake_tags.json", "intake_form.json"]:
        stale_path = os.path.join(UPLOAD_FOLDER, stale)
        if os.path.exists(stale_path):
            os.remove(stale_path)
    # Remove any previously uploaded PDFs/docs (keep only disclosures.xlsx)
    for fname in os.listdir(UPLOAD_FOLDER):
        if fname == "disclosures.xlsx":
            continue
        fpath = os.path.join(UPLOAD_FOLDER, fname)
        if os.path.isfile(fpath):
            os.remove(fpath)

    saved = []
    extracted = {}

    for f in files:
        path = os.path.join(UPLOAD_FOLDER, f.filename)
        f.save(path)
        saved.append(f.filename)

        # Universal text extraction — handle any supported format
        fname_lower = f.filename.lower()
        try:
            if fname_lower.endswith(".pdf"):
                text_pages = []
                with pdfplumber.open(path) as pdf:
                    for page in pdf.pages:
                        t = page.extract_text()
                        if t:
                            text_pages.append(t.strip())
                extracted[f.filename] = "\n\n".join(text_pages)

            elif fname_lower.endswith(".pptx") or fname_lower.endswith(".ppt"):
                from pptx import Presentation
                prs = Presentation(path)
                slide_texts = []
                for i, slide in enumerate(prs.slides, 1):
                    parts = []
                    for shape in slide.shapes:
                        if hasattr(shape, "text") and shape.text.strip():
                            parts.append(shape.text.strip())
                    if parts:
                        slide_texts.append(f"[Slide {i}]\n" + "\n".join(parts))
                extracted[f.filename] = "\n\n".join(slide_texts)

            elif fname_lower.endswith(".docx") or fname_lower.endswith(".doc"):
                import docx
                doc = docx.Document(path)
                paras = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
                # Also pull text from tables
                for table in doc.tables:
                    for row in table.rows:
                        row_text = " | ".join(c.text.strip() for c in row.cells if c.text.strip())
                        if row_text:
                            paras.append(row_text)
                extracted[f.filename] = "\n\n".join(paras)

            else:
                extracted[f.filename] = "[unsupported file type — no text extracted]"

        except Exception as e:
            extracted[f.filename] = f"[extraction error: {e}]"

    # Write fresh extracted_text.json for this run
    extracted_path = os.path.join(UPLOAD_FOLDER, "extracted_text.json")
    with open(extracted_path, "w") as fp:
        json.dump(extracted, fp, indent=2)

    return jsonify({"saved": saved, "extracted": list(extracted.keys())})


@app.route("/rules", methods=["GET"])
def get_rules():
    rules_path = os.path.join(UPLOAD_FOLDER, "rules.json")
    if not os.path.exists(rules_path):
        return jsonify({})
    with open(rules_path) as f:
        return jsonify(json.load(f))


@app.route("/intake-tags", methods=["GET"])
def get_intake_tags():
    path = os.path.join(UPLOAD_FOLDER, "intake_tags.json")
    if not os.path.exists(path):
        return jsonify({})
    with open(path) as f:
        return jsonify(json.load(f))


@app.route("/download-rules", methods=["GET"])
def download_rules():
    tier = request.args.get("tier", "baseline")
    excel_path = os.path.join(UPLOAD_FOLDER, "disclosures.xlsx")
    rules_path = os.path.join(UPLOAD_FOLDER, "rules.json")

    if not os.path.exists(excel_path) or not os.path.exists(rules_path):
        return jsonify({"error": "Missing disclosures or rules file"}), 400

    df = pd.read_excel(excel_path)
    with open(rules_path) as f:
        all_rules = json.load(f)

    tier_rules = all_rules.get(tier, all_rules.get("baseline", {}))

    # Flexible column detection
    display_col, lang_col = None, None
    for col in df.columns:
        cl = col.lower().strip()
        if cl in ("display_name", "disclosure name", "name", "disclosure_name", "title"):
            display_col = display_col or col
        if cl in ("disclosure", "disclosure language", "disclosure_language", "language", "text"):
            lang_col = lang_col or col

    rows = []
    for _, row in df.iterrows():
        name = row.get("name", "")
        rule_obj = tier_rules.get(name, {})
        rows.append({
            "Disclosure Name":     row.get(display_col, name) if display_col else name,
            "Disclosure Language": row.get(lang_col, "") if lang_col else "",
            "Rule":                rule_obj.get("rule", "No rule available"),
            "Placement":           rule_obj.get("placement", ""),
            "Tier":                tier
        })

    out_df = pd.DataFrame(rows)
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        out_df.to_excel(writer, index=False, sheet_name="Rationales")
        ws = writer.sheets["Rationales"]
        for col in ws.columns:
            max_len = max((len(str(cell.value)) if cell.value else 0) for cell in col)
            ws.column_dimensions[col[0].column_letter].width = min(max_len + 4, 80)
    output.seek(0)

    filename = f"Rationales_{tier}.xlsx"
    return send_file(output, as_attachment=True, download_name=filename,
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/save-document-tag", methods=["POST"])
def save_document_tag():
    data = request.get_json()
    filename = data.get("filename", "").strip()
    tag = data.get("tag", "").strip()
    if not filename:
        return jsonify({"error": "No filename provided"}), 400
    tags_path = os.path.join(UPLOAD_FOLDER, "document_tags.json")
    tags = {}
    if os.path.exists(tags_path):
        with open(tags_path) as f:
            tags = json.load(f)
    if isinstance(tag, str):
        tag = tag.strip()
    if tag:
        tags[filename] = tag
    elif filename in tags:
        del tags[filename]
    with open(tags_path, "w") as f:
        json.dump(tags, f, indent=2)
    return jsonify({"success": True})


@app.route("/reload-disclosures", methods=["GET"])
def reload_disclosures():
    excel_path = os.path.join(UPLOAD_FOLDER, "disclosures.xlsx")
    if not os.path.exists(excel_path):
        return jsonify({"error": "No disclosures file found"}), 400
    df = pd.read_excel(excel_path)
    df = df.dropna(how="all")
    columns = df.columns.tolist()
    rows = [clean_row(r) for r in df.to_dict(orient="records")]
    return jsonify({"columns": columns, "rows": rows})


@app.route("/generate-names", methods=["POST"])
def generate_names():
    excel_path = os.path.join(UPLOAD_FOLDER, "disclosures.xlsx")
    if not os.path.exists(excel_path):
        return jsonify({"error": "No disclosures uploaded yet."}), 400

    df = pd.read_excel(excel_path)
    df = df.dropna(how="all")

    # Flexible column detection
    display_col, lang_col = None, None
    for col in df.columns:
        cl = col.lower().strip()
        if cl in ("display_name", "disclosure name", "name", "disclosure_name", "title"):
            display_col = display_col or col
        if cl in ("disclosure", "disclosure language", "disclosure_language", "language", "text"):
            lang_col = lang_col or col

    # Find rows that are missing a display_name
    needs_name = []
    for i, row in df.iterrows():
        display = str(row.get(display_col, "") or "").strip() if display_col else ""
        lang    = str(row.get(lang_col, "") or "").strip() if lang_col else ""
        if not display and lang:
            needs_name.append((i, lang))

    if not needs_name:
        return jsonify({"skipped": True, "message": "All disclosures already have names."})

    disclosures_block = "\n".join(
        [f"{idx}. {lang[:600]}" for idx, (i, lang) in enumerate(needs_name, 1)]
    )

    prompt = f"""You are a financial compliance expert. For each disclosure text below, generate a short, professional display name (5–10 words max) in title case. The name should describe what the disclosure is about — like "Gross Returns — Performance (All Strategies)" or "Past Performance — Historical Track Record".

Output ONLY a JSON array of strings in the same order as the inputs, one name per disclosure. No explanation.

DISCLOSURES:
{disclosures_block}

Output format:
```json
["Name 1", "Name 2", ...]
```"""

    try:
        result = subprocess.run(
            ["claude", "-p", prompt],
            capture_output=True, text=True, timeout=120
        )
        if result.returncode != 0:
            return jsonify({"error": result.stderr[:500]}), 500

        match = re.search(r'```(?:json)?\s*(\[.*?\])\s*```', result.stdout, re.DOTALL)
        if not match:
            match = re.search(r'(\[.*\])', result.stdout, re.DOTALL)
        if not match:
            return jsonify({"error": "Could not parse names from Claude output."}), 500

        names = json.loads(match.group(1))

        for idx, (row_i, _) in enumerate(needs_name):
            if idx < len(names):
                df.at[row_i, "display_name"] = names[idx]

        df.to_excel(excel_path, index=False)
        return jsonify({"success": True, "generated": len(names)})

    except subprocess.TimeoutExpired:
        return jsonify({"error": "Timed out generating names."}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/generate-rules", methods=["POST"])
def generate_rules():
    excel_path  = os.path.join(UPLOAD_FOLDER, "disclosures.xlsx")
    extracted_path = os.path.join(UPLOAD_FOLDER, "extracted_text.json")
    rules_path  = os.path.join(UPLOAD_FOLDER, "rules.json")

    if not os.path.exists(excel_path):
        return jsonify({"error": "Upload a disclosures Excel first."}), 400

    # Load disclosures
    df = pd.read_excel(excel_path)
    df = df.dropna(how="all")

    # Normalize column names for flexible matching
    col_map = {}
    for col in df.columns:
        cl = col.lower().strip()
        if cl in ("display_name", "disclosure name", "name", "disclosure_name", "title"):
            col_map.setdefault("display_name", col)
        if cl in ("disclosure", "disclosure language", "disclosure_language", "language", "text", "disclosure text"):
            col_map.setdefault("disclosure", col)

    display_col = col_map.get("display_name")
    lang_col    = col_map.get("disclosure")

    # Detect document/page columns for fallback name generation
    doc_col  = next((c for c in df.columns if c.lower().strip() in ("document", "doc", "document name", "file")), None)
    page_col = next((c for c in df.columns if c.lower().strip() in ("page", "page number", "pg")), None)

    # Ensure name column is populated with unique slugs
    if "name" not in df.columns:
        df["name"] = ""
    df["name"] = df["name"].astype(object)

    def _is_blank_name(val):
        if val is None:
            return True
        if isinstance(val, float) and math.isnan(val):
            return True
        s = str(val).strip()
        return not s or bool(re.match(r'^nan(-\d+)?$', s))

    seen_slugs = set()
    for i, row in df.iterrows():
        if not _is_blank_name(row.get("name", None)):
            seen_slugs.add(str(row.get("name")).strip())

    for i, row in df.iterrows():
        if _is_blank_name(row.get("name", None)):
            # Always prefer doc+page over the name column (avoids circular reads)
            display = ""
            if doc_col:
                doc_part  = str(row.get(doc_col, "") or "").strip()
                raw_page  = row.get(page_col, "") if page_col else ""
                try:
                    page_part = str(int(float(raw_page))) if raw_page != "" else ""
                except (ValueError, TypeError):
                    page_part = str(raw_page).strip()
                display = f"{doc_part}_p{page_part}" if page_part else doc_part
            if not display and display_col and display_col != "name":
                display = str(row.get(display_col, "") or "").strip()
            if display:
                base_slug = slugify(display)
                slug = base_slug
                counter = 2
                while slug in seen_slugs:
                    slug = f"{base_slug}_{counter}"
                    counter += 1
                seen_slugs.add(slug)
                df.at[i, "name"] = slug
    df.to_excel(excel_path, index=False)

    # Detect position/placement column
    position_col = None
    for col in df.columns:
        if col.lower() in ("position", "placement", "location", "prominent or not prominent"):
            position_col = col
            break

    disclosures_block = ""
    for _, row in df.iterrows():
        name     = str(row.get("name", "") or "").strip()
        display  = str(row.get(display_col, name) or "").strip() if display_col else name
        lang     = str(row.get(lang_col, "") or "").strip() if lang_col else ""
        position = str(row.get(position_col, "") or "").strip() if position_col else ""
        if name:
            disclosures_block += f"\nNAME: {name}\nDISPLAY NAME: {display}"
            if position:
                disclosures_block += f"\nPOSITION: {position}"
            disclosures_block += f"\nDISCLOSURE LANGUAGE:\n{lang[:600]}\n---"

    # Load extracted document text — full corpus, no truncation
    doc_block = ""
    if os.path.exists(extracted_path):
        with open(extracted_path) as f:
            raw = f.read()
        doc_block = f"\n\nEXTRACTED DOCUMENT TEXT (for context on where disclosures appear):\n{raw}"

    # Load methodology
    methodology = ""
    methodology_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "METHODOLOGY.md")
    if os.path.exists(methodology_path):
        with open(methodology_path) as f:
            methodology = f.read()

    # Load document tags if available
    doc_tags_block = ""
    doc_tags_path = os.path.join(UPLOAD_FOLDER, "document_tags.json")
    if os.path.exists(doc_tags_path):
        with open(doc_tags_path) as f:
            doc_tags = json.load(f)
        if doc_tags:
            doc_tags_block = "\n\nDOCUMENT TAGS (each uploaded document and its intake form tags):\n"
            for fname, tags in doc_tags.items():
                if isinstance(tags, dict):
                    tag_str = ", ".join(f"{k}: {v}" for k, v in tags.items())
                else:
                    tag_str = str(tags)
                doc_tags_block += f"- {fname}: {tag_str}\n"

    # Load intake form if available
    intake_form_block = ""
    intake_tags_instruction = ""
    intake_form_path = os.path.join(UPLOAD_FOLDER, "intake_form.json")
    if os.path.exists(intake_form_path):
        with open(intake_form_path) as f:
            intake_form = json.load(f)
        intake_form_block = "\n\nINTAKE FORM DIMENSIONS (fields used to categorize documents; each has a list of possible values):\n"
        for dim, options in intake_form.items():
            intake_form_block += f"- {dim}: {', '.join(options)}\n"
        intake_tags_instruction = """

INTAKE TAGS TASK:
Using the uploaded documents (their extracted text and their tags) as your evidence base, suggest intake tag recommendations for each disclosure.

You have imperfect information — you only know about document types that were actually uploaded. Apply these two rules:

1. INCLUDE (mode: "include") — if you have seen this disclosure appear in documents of a given type, suggest including that type. Do NOT say "only" — there may be other types you haven't seen where it also applies.

2. EXCLUDE (mode: "exclude") — if you have uploaded documents of a given type AND this disclosure is clearly absent or irrelevant in all of them, suggest excluding that type.

Never recommend a type (include or exclude) if you have no uploaded documents of that type — you simply don't know.

After the rules JSON block, output a second block labeled exactly "INTAKE_TAGS:" followed by a JSON code block:

INTAKE_TAGS:
```json
{
  "disclosure_name_key": {
    "Asset Type": { "mode": "include", "values": ["Pitch Deck", "Overview Deck"] },
    "Distribution": { "mode": "exclude", "values": ["Internal"] }
  }
}
```

Rules:
- A disclosure can have both include and exclude entries for different dimensions
- Only include a dimension if you have actual document evidence for your recommendation
- Key by the disclosure NAME field (same keys as the rules above)
"""

    prompt = f"""You are a financial compliance expert generating disclosure placement rules.

METHODOLOGY (follow this strictly):
{methodology}

DISCLOSURES TO GENERATE RULES FOR:
{disclosures_block}
{doc_block}
{doc_tags_block}
{intake_form_block}

TASK:
For each disclosure above, analyze its language (and any matching evidence in the extracted documents) and generate a BASELINE rule following the conservative methodology.

Output ONLY a single JSON code block in exactly this format — no explanation, no extra text:

```json
{{
  "disclosure_name_key": {{
    "placement": "footnote",
    "rule": "Trigger ONLY when... Do NOT trigger on...",
    "triggers": ["exact phrase 1", "exact phrase 2"]
  }}
}}
```

Rules:
- placement must be "footnote" or "back"
- rule must include explicit "Do NOT trigger on..." guardrails
- triggers must be specific exact phrases, not broad topics
- Be conservative — it is better to miss a placement than to recommend one incorrectly
- Output ALL disclosures in the JSON, keyed by their NAME field (not display name)

PLACEMENT LOGIC — use the POSITION field to inform how you write triggers:
- "Same page" / "footnote" → the trigger must be something that appears ON THE SAME PAGE as the disclosure. The root cause of the disclosure firing is co-located with it. Write triggers as slide-level or page-level evidence (e.g. "this slide contains X", "a table on this page shows Y").
- "Back of document" → the trigger is something that applies to the document broadly. The disclosure appears once at the end as a global note. Write triggers as document-level evidence (e.g. "the document discusses X anywhere", "the document contains any slide showing Y").
- If POSITION is blank or ambiguous, use your best judgement based on the disclosure language.
{intake_tags_instruction}
"""

    try:
        result = subprocess.run(
            ["claude", "-p", prompt],
            capture_output=True, text=True, timeout=300
        )

        if result.returncode != 0:
            return jsonify({"error": f"Claude error: {result.stderr[:500]}"}), 500

        output = result.stdout

        # Extract JSON from code block
        match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', output, re.DOTALL)
        if not match:
            match = re.search(r'(\{.*\})', output, re.DOTALL)
        if not match:
            return jsonify({"error": "Could not parse JSON from Claude output."}), 500

        baseline_rules = json.loads(match.group(1))

        # Expand to all 5 tiers from baseline
        all_tiers = {t: {} for t in ["baseline", "exclusive", "most_exclusive", "inclusive", "most_inclusive"]}
        for name, base in baseline_rules.items():
            placement = base.get("placement", "footnote")
            base_rule = base.get("rule", "")
            triggers  = base.get("triggers", [])
            topic     = triggers[0] if triggers else name.replace("_", " ")

            all_tiers["baseline"][name]       = base
            all_tiers["exclusive"][name]      = {"placement": placement, "rule": f"{base_rule} Additionally, at least one corroborating element must be present on the same slide.", "triggers": triggers}
            all_tiers["most_exclusive"][name] = {"placement": placement, "rule": f"Trigger ONLY when ALL THREE of the following are simultaneously present: (1) {topic} is explicitly labeled, (2) specific numeric values are shown alongside it, AND (3) a corroborating metric or table header is also present. Do NOT trigger unless all three conditions are unambiguously met.", "triggers": triggers}
            all_tiers["inclusive"][name]      = {"placement": placement, "rule": f"Trigger when the slide discusses {topic} or closely related concepts with any supporting data. May trigger on summary or overview slides referencing these metrics.", "triggers": triggers}
            all_tiers["most_inclusive"][name] = {"placement": placement, "rule": f"Trigger whenever {topic} or any conceptually related term appears in any context, including passing references, headers, or narrative prose.", "triggers": triggers}

        with open(rules_path, "w") as f:
            json.dump(all_tiers, f, indent=2)

        # Parse intake tags if present
        intake_tags_count = 0
        intake_match = re.search(r'INTAKE_TAGS:\s*```(?:json)?\s*(\{.*?\})\s*```', output, re.DOTALL)
        if intake_match:
            try:
                intake_tags = json.loads(intake_match.group(1))
                intake_tags_path = os.path.join(UPLOAD_FOLDER, "intake_tags.json")
                with open(intake_tags_path, "w") as f:
                    json.dump(intake_tags, f, indent=2)
                intake_tags_count = len(intake_tags)
            except Exception:
                pass

        return jsonify({"success": True, "count": len(baseline_rules), "intake_tags_count": intake_tags_count})

    except subprocess.TimeoutExpired:
        return jsonify({"error": "Timed out — try again."}), 500
    except json.JSONDecodeError as e:
        return jsonify({"error": f"JSON parse error: {str(e)}"}), 500
    except FileNotFoundError:
        return jsonify({"error": "Claude CLI not found. Make sure Claude Code is installed."}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/generate-tag-vocabulary", methods=["POST"])
def generate_tag_vocabulary():
    excel_path = os.path.join(UPLOAD_FOLDER, "disclosures.xlsx")
    extracted_path = os.path.join(UPLOAD_FOLDER, "extracted_text.json")

    if not os.path.exists(excel_path):
        return jsonify({"error": "Upload a disclosures Excel first."}), 400

    df = pd.read_excel(excel_path)
    df = df.dropna(how="all")

    disclosures_block = ""
    for _, row in df.iterrows():
        display = str(row.get("display_name", "") or "").strip()
        lang    = str(row.get("disclosure", "") or "").strip()
        if display or lang:
            disclosures_block += f"\n- {display}: {lang[:300]}\n"

    doc_block = ""
    if os.path.exists(extracted_path):
        with open(extracted_path) as f:
            raw = f.read()
        doc_block = f"\n\nEXTRACTED DOCUMENT TEXT (sample):\n{raw[:8000]}"

    prompt = f"""You are a financial compliance expert. Analyze the disclosure language below and suggest intake tags sorted into two buckets:

1. **Type of Material** — what kind of document is it? (e.g. fact_sheet, ddq, lp_advisory_committee, investment_memorandum, pitch_deck)
2. **Theme of Material** — what investment strategy or asset class does it cover? (e.g. credit, private_equity, all_strategies, real_estate)

These tags categorize CLIENT DOCUMENTS, not disclosures. A document might be tagged with one from each bucket (e.g. "fact_sheet" + "credit").

Rules:
- Lowercase with underscores
- 3–6 tags per bucket
- Type tags must read as a kind of document or material — always end with a word like _deck, _report, _memo, _materials, _sheet, _questionnaire, _update where needed (e.g. lp_advisory_committee_materials, not lp_advisory_committee)
- Theme tags = investment strategy/asset class, NOT document format

DISCLOSURES (use these to infer what kinds of documents this firm produces):
{disclosures_block}
{doc_block}

Output ONLY a JSON object with two arrays. No explanation.

```json
{{
  "type": ["fact_sheet", "ddq", "lp_advisory_committee"],
  "theme": ["credit", "private_equity", "all_strategies"]
}}
```"""

    try:
        result = subprocess.run(
            ["claude", "-p", prompt],
            capture_output=True, text=True, timeout=120
        )
        if result.returncode != 0:
            return jsonify({"error": result.stderr[:500]}), 500

        output = result.stdout
        match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', output, re.DOTALL)
        if not match:
            match = re.search(r'(\{.*\})', output, re.DOTALL)
        if not match:
            return jsonify({"error": "Could not parse tags from Claude output."}), 500

        buckets = json.loads(match.group(1))
        return jsonify({"success": True, "buckets": buckets})

    except subprocess.TimeoutExpired:
        return jsonify({"error": "Timed out — try again."}), 500
    except json.JSONDecodeError as e:
        return jsonify({"error": f"JSON parse error: {str(e)}"}), 500
    except FileNotFoundError:
        return jsonify({"error": "Claude CLI not found."}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(debug=True)
