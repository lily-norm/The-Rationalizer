# Rationalizer — Setup Guide

## What This Is
The Rationalizer is a web app that analyzes financial client documents (PDFs) and recommends where disclosure language should appear, based on rules derived from example documents.

## Requirements
- Python 3.9+
- Internet connection (to load Rubik font from Google Fonts)

## Installation
Run these commands in your terminal:

```bash
pip3 install flask pandas openpyxl docling anthropic
```

## Running the App
```bash
cd disclosure_tool
python3 app.py
```
Then open your browser to: **http://localhost:5000**

## How to Use
1. **Upload client documents** — drag and drop your "gold star" finished PDFs (documents that already have disclosures correctly placed)
2. **Upload disclosure language** — drag and drop your Excel file with disclosure titles and language (columns: `name`, `display_name`, `disclosure`)
3. **View rationales** — the app displays each disclosure with its rule and trigger keywords underneath

## File Structure
```
disclosure_tool/
├── app.py                  # Flask backend
├── templates/
│   └── index.html          # Web UI
├── uploads/
│   ├── disclosures.xlsx    # Your disclosure language Excel
│   ├── rules.json          # Generated rules (see METHODOLOGY.md)
│   └── extracted_text.json # Cached PDF text extractions
└── README.md
```

## Re-generating Rules
If you have new example documents or want to update the rules, see `METHODOLOGY.md` for the full process and the conservative rules philosophy.
