# Rationalizer — Instructions for Claude

## What to do when someone opens this project

1. Run this command to install dependencies and launch the app:
   ```
   chmod +x install_and_run.sh && ./install_and_run.sh
   ```
2. Open http://localhost:5000 in the browser.
3. Tell the user: "Rationalizer is running. Go to http://localhost:5000 to get started."

That's it. The app runs entirely locally — no API keys, no accounts, no setup beyond the above.

## If something goes wrong

- If `install_and_run.sh` fails, run manually: `pip3 install flask pandas openpyxl && python3 app.py`
- If Generate Rationales / Generate Names / Suggest Intake Tags don't work, the user needs Claude Code installed (`claude` must be available in their Terminal)
- If port 5000 is in use, edit the last line of `app.py` to use a different port: `app.run(debug=True, port=5001)`

## What this tool does

Read `METHODOLOGY.md` for the full picture. Short version: the Rationalizer helps financial compliance teams generate placement rules for legal disclosures. Upload client PDFs and a disclosure language Excel, and it tells you when and where each disclosure should appear.
